EXAMPLE_PATH = "../data/example.json"
FORMAT_PATH = "../data/format.json"
TOOLS_PATH = "../data/tools.json"
TOKEN_PATH = "../token_usage.txt"